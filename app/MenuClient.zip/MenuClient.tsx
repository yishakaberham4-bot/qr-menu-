 'use client'

import { useState } from 'react'

type Category = {
  id: string
  name: string
  sort_order: number
}

type MenuItem = {
  id: string
  category_id: string
  name: string
  description: string | null
  price: number
  available: boolean
  image_url: string | null
}

export default function MenuClient({
  categories,
  items,
}: {
  categories: Category[]
  items: MenuItem[]
}) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [search, setSearch] = useState('')

  // Filter items
  const filteredItems = items.filter((item) => {
    const matchesCategory = selectedCategory ? item.category_id === selectedCategory : true
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      (item.description?.toLowerCase().includes(search.toLowerCase()) ?? false)

    return item.available && matchesCategory && matchesSearch
  })

  // Group filtered items by category
  const grouped = categories
    .map((cat) => ({
      ...cat,
      items: filteredItems.filter((item) => item.category_id === cat.id),
    }))
    .filter((cat) => cat.items.length > 0)

  return (
    <>
      {/* Search */}
      <div className="max-w-md mx-auto mb-8">
        <input
          type="text"
          placeholder="Search the menu..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full px-6 py-3 rounded-full border border-[#e8d9c5] bg-white/80 backdrop-blur text-[#3d2b1f] placeholder:text-[#a8947e] focus:outline-none focus:ring-2 focus:ring-[#c9a86c]"
        />
      </div>

      {/* Category Pills */}
      <div className="flex gap-3 overflow-x-auto pb-4 mb-10 scrollbar-hide">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition ${
            selectedCategory === null
              ? 'bg-[#3d2b1f] text-white'
              : 'bg-white border border-[#e8d9c5] text-[#3d2b1f] hover:bg-[#f0e6d8]'
          }`}
        >
          ALL
        </button>

        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition ${
              selectedCategory === cat.id
                ? 'bg-[#3d2b1f] text-white'
                : 'bg-white border border-[#e8d9c5] text-[#3d2b1f] hover:bg-[#f0e6d8]'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Menu Items */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {grouped.map((category) => (
          <div
            key={category.id}
            className="bg-white/90 backdrop-blur rounded-3xl p-6 shadow-sm border border-[#f0e6d8]"
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="bg-[#c9a86c] text-white text-xs font-medium px-3 py-1 rounded-full">
                {category.name.toUpperCase()}
              </span>
            </div>

            <div className="space-y-5">
              {category.items.map((item) => (
                <div key={item.id} className="flex items-center gap-4">
                  {/* Image */}
                  <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-[#f0e6d8]">
                    {item.image_url ? (
                      <img
                        src={item.image_url}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[#c9a86c] text-xs">
                        No img
                      </div>
                    )}
                  </div>

                  {/* Name */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-[#3d2b1f] text-lg leading-tight">
                      {item.name}
                    </h3>
                    {item.description && (
                      <p className="text-sm text-[#8a7a6a] mt-0.5 line-clamp-1">
                        {item.description}
                      </p>
                    )}
                  </div>

                  {/* Price + Button */}
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <span className="font-semibold text-[#3d2b1f] text-lg">
                      {Number(item.price).toFixed(0)}
                    </span>
                    <button className="w-9 h-9 rounded-full border-2 border-[#c9a86c] text-[#c9a86c] flex items-center justify-center hover:bg-[#c9a86c] hover:text-white transition text-lg">
                      +
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {grouped.length === 0 && (
        <div className="text-center py-20 text-[#8a7a6a]">
          No items found.
        </div>
      )}
    </>
  )
}